import 'package:material_ui/material_ui.dart';

import 'screens/home/home_screen.dart';
import 'screens/intro/intro_screen.dart';

void main() {
  runApp(const MelodyApp());
}

class MelodyApp extends StatelessWidget {
  const MelodyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: IntroScreen(destination: const HomeScreen()),
    );
  }
}
