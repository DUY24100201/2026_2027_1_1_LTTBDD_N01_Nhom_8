import 'package:material_ui/material_ui.dart';

const Color bgColor = Color(0xFF15121F);
const Color cardColor = Color(0xFF252131);
const Color primaryColor = Color(0xFFB87553);
const Color textColor = Colors.white;
const Color subTextColor = Color(0xFFB5B0C0);

class PlayerScreen extends StatefulWidget {
  final String songName;
  final String artist;
  final Color coverColor;
  final IconData coverIcon;

  const PlayerScreen({
    super.key,
    required this.songName,
    required this.artist,
    required this.coverColor,
    required this.coverIcon,
  });

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  bool isPlaying = false;
  bool isFavorite = false;
  bool isShuffle = false;
  bool isRepeat = false;

  double progress = 0;

  final Duration totalDuration = const Duration(minutes: 4, seconds: 20);

  String formatDuration(Duration duration) {
    final minutes = duration.inMinutes.toString().padLeft(2, '0');
    final seconds = (duration.inSeconds % 60).toString().padLeft(2, '0');

    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final currentDuration = Duration(
      seconds: (totalDuration.inSeconds * progress).toInt(),
    );

    return Scaffold(
      backgroundColor: bgColor,
      appBar: AppBar(
        backgroundColor: bgColor,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(
            Icons.keyboard_arrow_down,
            color: textColor,
            size: 30,
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Column(
          children: [
            Text(
              'ĐANG PHÁT',
              style: TextStyle(
                color: subTextColor,
                fontSize: 11,
                letterSpacing: 2,
              ),
            ),
            SizedBox(height: 3),
            Text(
              'Melody Music Player',
              style: TextStyle(
                color: textColor,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.more_vert, color: textColor),
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
          child: Column(
            children: [
              const SizedBox(height: 20),

              // Ảnh bìa bài hát
              Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 340),
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(25),
                        gradient: LinearGradient(
                          colors: [widget.coverColor, cardColor],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: widget.coverColor.withValues(alpha: 0.3),
                            blurRadius: 25,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Icon(
                        widget.coverIcon,
                        size: 120,
                        color: Colors.white.withValues(alpha: 0.8),
                      ),
                    ),
                  ),
                ),
              ),

              const SizedBox(height: 35),

              // Tên bài hát và nghệ sĩ
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.songName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: textColor,
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          widget.artist,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: subTextColor,
                            fontSize: 15,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () {
                      setState(() {
                        isFavorite = !isFavorite;
                      });
                    },
                    icon: Icon(
                      isFavorite ? Icons.favorite : Icons.favorite_border,
                      color: isFavorite ? Colors.redAccent : primaryColor,
                      size: 28,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 25),

              // Thanh tiến trình
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: primaryColor,
                  inactiveTrackColor: cardColor,
                  thumbColor: primaryColor,
                  overlayColor: primaryColor.withValues(alpha: 0.2),
                  trackHeight: 4,
                ),
                child: Slider(
                  min: 0,
                  max: 1,
                  value: progress,
                  onChanged: (value) {
                    setState(() {
                      progress = value;
                    });
                  },
                ),
              ),

              // Thời gian bài hát
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      formatDuration(currentDuration),
                      style: const TextStyle(color: subTextColor, fontSize: 12),
                    ),
                    Text(
                      formatDuration(totalDuration),
                      style: const TextStyle(color: subTextColor, fontSize: 12),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 25),

              // Các nút điều khiển
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // Shuffle
                  IconButton(
                    onPressed: () {
                      setState(() {
                        isShuffle = !isShuffle;
                      });
                    },
                    icon: Icon(
                      Icons.shuffle,
                      color: isShuffle ? primaryColor : subTextColor,
                    ),
                  ),

                  // Bài trước
                  IconButton(
                    onPressed: () {
                      setState(() {
                        progress = 0;
                      });
                    },
                    icon: const Icon(
                      Icons.skip_previous,
                      color: textColor,
                      size: 38,
                    ),
                  ),

                  // Play / Pause
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        isPlaying = !isPlaying;
                      });
                    },
                    child: Container(
                      width: 68,
                      height: 68,
                      decoration: const BoxDecoration(
                        color: primaryColor,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(
                        isPlaying ? Icons.pause : Icons.play_arrow,
                        color: Colors.white,
                        size: 38,
                      ),
                    ),
                  ),

                  // Bài tiếp theo
                  IconButton(
                    onPressed: () {
                      setState(() {
                        progress = 0;
                      });
                    },
                    icon: const Icon(
                      Icons.skip_next,
                      color: textColor,
                      size: 38,
                    ),
                  ),

                  // Repeat
                  IconButton(
                    onPressed: () {
                      setState(() {
                        isRepeat = !isRepeat;
                      });
                    },
                    icon: Icon(
                      Icons.repeat,
                      color: isRepeat ? primaryColor : subTextColor,
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 35),

              // Danh sách phát
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: const Color(0xFF49385E)),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.queue_music, color: primaryColor, size: 25),
                    SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Danh sách phát',
                        style: TextStyle(
                          color: textColor,
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Icon(Icons.keyboard_arrow_right, color: subTextColor),
                  ],
                ),
              ),

              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}
